public class Student{
    int ID;
    String name;
    int age;
    String grade;

    public Student(int ID, String name, int age, String grade) {
        this.ID = ID;
        this.name = name;
        this.age = age;
        this.grade = grade;
    }
}




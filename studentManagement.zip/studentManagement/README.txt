READ.ME

to get started you need to run 'Main.java'
for running you will need to enter the max number of students.Once a number is entered you will be given 6 different chooses.
By entering the number next to the option you will select that choose.
By selecting
1. Add a Student by filling their ID,name,age,grade.
    Examples for or how filling the fields out:
    ID: (11, 2056, 1738, 1, 23, 696).
    Name: Amaury Garcia, Juan Martinez, Renee Rosado, Lilyana Rosado.
    Age: 10, 23, 45, 50.
    Grade:(1st, 5th, 3rd, 12th, or 2nd)


2. Delete Student by filling out one of the fields or all them.
    A.you will be given 4 different chooses:
        I. Enter ID or -1 to skip.
        II. Enter name or press enter to skip.
        III. Enter age or -1 to skip.
        IV. Enter grade or press enter to skip.

3. Search Student by filling out one of the fields or all them.
    A.you will be given 4 different chooses:
    B. you have to enter it exactly have it was entered.
        I. Enter ID or -1 to skip.
        II. Enter name or press enter to skip.
        III. Enter age or -1 to skip.
        IV. Enter grade or press enter to skip.

4. Display all the students you added to the list.

5. Sort all the students based on ID,name,age,or grade.
    A. you will be given 5 different chooses:
        I. sorting by ID.
        II. sorting by name.
        III. sorting by age.
        IV. sorting by grade.
        V. exiting back to the first selection

6. Will make you exit the program.